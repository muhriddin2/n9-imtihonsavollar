const body=document.querySelector('body')
const form=document.querySelector('form')
function random_color() {
    return '#' + Math.floor(Math.random()*16777215).toString(16)
}

form.addEventListener('submit',(e)=>{
    e.preventDefault()
    console.log('hidw');
    let color_r = random_color();
    body.style.cssText = `background-color: ${color_r}`;
})

