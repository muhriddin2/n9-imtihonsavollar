const a=+prompt('enter a')
const b=+prompt('enter b')

if (a>b) {
    for (let i = 1; i <=b; i++) {
        if (b%i==0 && a%i==0) {
            s=i
        }
        
    }
    console.log(s);
}else if (a<b) {
    for (let i = 1; i <=a; i++) {
        if (b%i==0 && a%i==0) {
            s=i
        }
        
    }
    console.log(s);
}else {
    console.log(a);
}

