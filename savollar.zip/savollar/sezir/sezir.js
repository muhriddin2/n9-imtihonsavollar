const arr=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
const soz=prompt('soz').toLowerCase().split('')


const a=+prompt('a')
let sum=''

for (let i = 0; i < arr.length; i++) {

    for (let j = 0; j <=soz.length; j++) {
        if (arr[i]==soz[j]) {
            sum+=arr[i+a]
        }
    }

}
console.log(sum);
